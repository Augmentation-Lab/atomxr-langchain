# color

CS Type: array
Description: Color is an array of comma separated integers/floats representing the RGB