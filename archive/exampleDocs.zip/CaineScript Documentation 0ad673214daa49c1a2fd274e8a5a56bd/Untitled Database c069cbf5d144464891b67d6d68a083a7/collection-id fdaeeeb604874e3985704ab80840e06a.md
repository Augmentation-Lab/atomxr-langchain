# collection-id

CS Type: string