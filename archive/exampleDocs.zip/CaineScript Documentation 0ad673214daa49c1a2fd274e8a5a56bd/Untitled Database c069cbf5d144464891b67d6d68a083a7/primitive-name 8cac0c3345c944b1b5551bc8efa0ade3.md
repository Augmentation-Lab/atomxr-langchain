# primitive-name

CS Type: string
Description: “cube”, “sphere”, “cylinder”, “capsule”