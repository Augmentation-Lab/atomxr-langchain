# resource-name

CS Type: string
Description: the name of a sound file, or prefab, etc.