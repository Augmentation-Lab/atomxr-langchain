# Speed

Description: Speed can be “slow”, “medium”, or “fast”
Tags: string