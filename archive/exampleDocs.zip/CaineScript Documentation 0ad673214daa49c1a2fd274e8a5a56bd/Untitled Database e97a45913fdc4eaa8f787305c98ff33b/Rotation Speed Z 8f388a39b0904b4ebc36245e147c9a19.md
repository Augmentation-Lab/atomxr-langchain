# Rotation Speed Z

Tags: float, integer