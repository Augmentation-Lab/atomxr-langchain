# sound clip name

Tags: resource-name